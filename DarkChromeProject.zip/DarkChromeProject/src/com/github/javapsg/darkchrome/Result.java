package com.github.javapsg.darkchrome;

public enum Result {
	TRUE,
	FALSE,
	NULL
}
